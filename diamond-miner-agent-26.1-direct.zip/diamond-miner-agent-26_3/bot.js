'use strict'

const fs = require('node:fs')
const path = require('node:path')
const mineflayer = require('mineflayer')
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder')
const collectBlockPlugin = require('mineflayer-collectblock').plugin
const pvpPlugin = require('mineflayer-pvp').plugin

const CONFIG_PATH = path.join(__dirname, 'config.json')

function loadConfig () {
  if (!fs.existsSync(CONFIG_PATH)) {
    throw new Error('config.json is missing. Copy config.example.json to config.json and edit it first.')
  }

  const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'))
  const required = [
    ['server.host', config.server?.host],
    ['server.username', config.server?.username],
    ['owner', config.owner]
  ]
  for (const [key, value] of required) {
    if (typeof value !== 'string' || !value.trim() || value.startsWith('YOUR_')) {
      throw new Error(`Please set ${key} in config.json.`)
    }
  }

  if (!['microsoft', 'offline'].includes(config.server.auth)) {
    throw new Error('server.auth must be "microsoft" or "offline".')
  }
  if (!['north', 'south', 'east', 'west'].includes(config.mining?.tunnelDirection)) {
    throw new Error('mining.tunnelDirection must be north, south, east, or west.')
  }

  config.combat = {
    enabled: true,
    detectRadius: 9,
    maxFightSeconds: 18,
    retreatHealth: 8,
    ...(config.combat || {})
  }
  config.storage = {
    autoDepositDiamonds: true,
    depositAtCount: 16,
    chestPosition: null,
    returnAfterDeposit: true,
    ...(config.storage || {})
  }

  return config
}

const config = loadConfig()
const port = Number(config.server.port || 25565)
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error('server.port must be a valid TCP port (1–65535).')
}

const EDIBLE_FOOD = [
  'golden_carrot', 'cooked_beef', 'cooked_porkchop', 'cooked_mutton',
  'cooked_chicken', 'cooked_rabbit', 'cooked_salmon', 'cooked_cod',
  'baked_potato', 'bread', 'carrot', 'apple', 'pumpkin_pie',
  'sweet_berries', 'melon_slice', 'dried_kelp'
]

const HOSTILE_MOBS = new Set([
  'zombie', 'zombie_villager', 'husk', 'drowned',
  'skeleton', 'stray', 'wither_skeleton', 'bogged',
  'spider', 'cave_spider', 'silverfish', 'endermite',
  'witch', 'pillager', 'vindicator', 'evoker', 'vex',
  'slime', 'magma_cube', 'phantom',
  'blaze', 'hoglin', 'zoglin', 'piglin_brute',
  'guardian', 'breeze'
])

// These mobs are deliberately not melee-engaged: doing so can cause an explosion,
// an almost-certain death, or an encounter that requires ranged equipment.
const AVOID_COMBAT_MOBS = new Set([
  'creeper', 'warden', 'wither', 'ender_dragon', 'ravager',
  'elder_guardian', 'ghast', 'enderman'
])

const WEAPON_PRIORITY = [
  'netherite_sword', 'diamond_sword', 'iron_sword', 'stone_sword', 'wooden_sword', 'golden_sword',
  'netherite_axe', 'diamond_axe', 'iron_axe', 'stone_axe', 'wooden_axe', 'golden_axe'
]

const directionVectors = {
  north: { x: 0, z: -1 },
  south: { x: 0, z: 1 },
  east: { x: 1, z: 0 },
  west: { x: -1, z: 0 }
}

const direction = directionVectors[config.mining.tunnelDirection]
const minHealth = Number(config.safety?.minimumHealth ?? 10)
const minFood = Number(config.safety?.minimumFood ?? 7)
const maxSlots = Number(config.safety?.maxOccupiedInventorySlots ?? 31)
const scanRadius = Number(config.mining?.scanRadius ?? 32)
const maxTunnelSteps = Number(config.mining?.maxTunnelSteps ?? 120)
const maxFailedTargets = Number(config.mining?.maxFailedTargets ?? 8)
const lavaSafetyRadius = Number(config.safety?.lavaSafetyRadius ?? 1)
const miningY = Number(config.mining?.miningY ?? -58)

const bot = mineflayer.createBot({
  host: config.server.host.trim(),
  port,
  username: config.server.username.trim(),
  auth: config.server.auth,
  // Use the Minecraft version supported by Mineflayer for a direct connection.
  ...(config.server.version ? { version: String(config.server.version) } : {}),
  // There is deliberately no reconnect loop or server keep-alive behavior.
  hideErrors: false
})

bot.loadPlugin(pathfinder)
bot.loadPlugin(collectBlockPlugin)
bot.loadPlugin(pvpPlugin)

const state = {
  spawned: false,
  running: false,
  busy: false,
  stopRequested: false,
  homeRequested: false,
  homePosition: null,
  chestPosition: config.storage.chestPosition || null,
  movements: null,
  tunnelSteps: 0,
  failedTargets: 0,
  minedOres: 0,
  mobsDefeated: 0,
  combatBusy: false,
  combatRequested: false,
  hostileScanTimer: null,
  blacklist: new Map()
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))
const posKey = p => `${p.x},${p.y},${p.z}`
const say = message => {
  console.log(`[BOT] ${message}`)
  if (state.spawned) {
    try { bot.chat(`[Miner] ${message}`) } catch {}
  }
}

function saveConfig () {
  fs.writeFileSync(CONFIG_PATH, `${JSON.stringify(config, null, 2)}\n`, 'utf8')
}

function blockIsAir (block) {
  return !block || block.boundingBox === 'empty' || block.name === 'air' || block.name === 'cave_air' || block.name === 'void_air'
}

function isLiquid (block) {
  if (!block) return false
  return /^(water|lava)$/.test(block.name) || block.name.endsWith('_water')
}

function isHazardous (block) {
  if (!block) return true
  return isLiquid(block) || block.name === 'fire' || block.name === 'soul_fire'
}

function isGravityBlock (block) {
  return block && ['sand', 'red_sand', 'gravel', 'suspicious_sand', 'suspicious_gravel'].includes(block.name)
}

function hasSafePickaxe () {
  const allowed = new Set(['iron_pickaxe', 'diamond_pickaxe', 'netherite_pickaxe'])
  return bot.inventory.items().some(item => allowed.has(item.name))
}

function countOccupiedInventorySlots () {
  const slots = bot.inventory.slots || []
  return slots.slice(9, 45).filter(Boolean).length
}

function countDiamonds () {
  return bot.inventory.items()
    .filter(item => item.name === 'diamond')
    .reduce((sum, item) => sum + item.count, 0)
}

function safetyStopReason () {
  if (typeof bot.health === 'number' && bot.health <= minHealth) {
    return `Health is low (${bot.health}). Heal before mining again.`
  }
  if (typeof bot.food === 'number' && bot.food <= minFood) {
    return `Food is low (${bot.food}) and no usable food was available. Restock before mining again.`
  }
  const occupied = countOccupiedInventorySlots()
  if (occupied >= maxSlots) {
    return `Inventory is nearly full (${occupied}/36 slots). Empty it before mining again.`
  }
  if (!hasSafePickaxe()) {
    return 'No iron, diamond, or netherite pickaxe found. A stone/wood/gold pickaxe cannot harvest diamond ore.'
  }
  return null
}

function nearbyLiquidOrHazard (block, radius = lavaSafetyRadius) {
  if (!block) return true
  for (let dx = -radius; dx <= radius; dx++) {
    for (let dy = -radius; dy <= radius; dy++) {
      for (let dz = -radius; dz <= radius; dz++) {
        if (dx === 0 && dy === 0 && dz === 0) continue
        const neighbour = bot.blockAt(block.position.offset(dx, dy, dz))
        if (!neighbour || isHazardous(neighbour)) return true
      }
    }
  }
  return false
}

function getDiamondBlockIds () {
  return ['diamond_ore', 'deepslate_diamond_ore']
    .map(name => bot.registry.blocksByName[name]?.id)
    .filter(id => Number.isInteger(id))
}

function findNearestSafeDiamond () {
  const ids = getDiamondBlockIds()
  if (!ids.length) return null

  const now = Date.now()
  for (const [key, until] of state.blacklist) {
    if (until <= now) state.blacklist.delete(key)
  }

  const positions = bot.findBlocks({ matching: ids, maxDistance: scanRadius, count: 40 })
  for (const position of positions) {
    const key = posKey(position)
    if (state.blacklist.has(key)) continue
    const block = bot.blockAt(position)
    if (!block || nearbyLiquidOrHazard(block)) continue
    return block
  }
  return null
}

async function equipBestToolFor (block) {
  const tool = bot.pathfinder.bestHarvestTool(block)
  if (tool) await bot.equip(tool, 'hand')
}

async function eatFoodIfNeeded () {
  if (typeof bot.food !== 'number' || bot.food >= 16) return false
  const inventory = bot.inventory.items()
  let food = null
  for (const name of EDIBLE_FOOD) {
    food = inventory.find(item => item.name === name)
    if (food) break
  }
  if (!food) return false
  await bot.equip(food, 'hand')
  await bot.consume()
  console.log(`[FOOD] Ate ${food.name}; food level is now ${bot.food}.`)
  return true
}

function findNearestHostile () {
  if (!config.combat.enabled || !bot.entity) return null
  const radius = Number(config.combat.detectRadius || 9)
  let nearest = null
  let nearestDistance = Infinity

  for (const entity of Object.values(bot.entities)) {
    if (!entity || entity === bot.entity || entity.type !== 'mob') continue
    if (!entity.position || entity.isValid === false) continue
    if (!HOSTILE_MOBS.has(entity.name) && !AVOID_COMBAT_MOBS.has(entity.name)) continue
    const distance = entity.position.distanceTo(bot.entity.position)
    if (distance <= radius && distance < nearestDistance) {
      nearest = entity
      nearestDistance = distance
    }
  }
  return nearest
}

function requestCombatInterrupt () {
  if (!state.running || state.combatRequested || state.combatBusy || state.stopRequested || state.homeRequested) return
  const target = findNearestHostile()
  if (!target) return

  state.combatRequested = true
  console.log(`[COMBAT] Hostile mob detected: ${target.name}; interrupting mining to respond.`)

  // Stop an in-progress collect-block path so the miner can handle the mob first.
  if (bot.collectBlock) {
    void bot.collectBlock.cancelTask().catch(error => console.warn('[COMBAT] Could not cancel collection task:', error.message))
  }
  try { bot.pathfinder.setGoal(null) } catch {}
}

function bestMeleeWeapon () {
  const items = bot.inventory.items()
  for (const name of WEAPON_PRIORITY) {
    const match = items.find(item => item.name === name)
    if (match) return match
  }
  return null
}

async function fightNearbyHostile () {
  state.combatRequested = false
  const target = findNearestHostile()
  if (!target) return false

  state.combatBusy = true
  try {
    if (AVOID_COMBAT_MOBS.has(target.name)) {
      state.running = false
      say(`Dangerous mob detected (${target.name}). I will not melee it; mining stopped to avoid an unsafe fight.`)
      await goHome()
      return true
    }

    if (typeof bot.health === 'number' && bot.health <= Number(config.combat.retreatHealth || 8)) {
      state.running = false
      say(`Health is too low to fight (${bot.health}/20). Mining stopped; returning to the saved starting area.`)
      await goHome()
      return true
    }

    const weapon = bestMeleeWeapon()
    if (!weapon) {
      state.running = false
      say(`A ${target.name} is nearby, but I have no sword or axe. Mining stopped; bring a weapon and restart.`)
      await goHome()
      return true
    }

    await bot.equip(weapon, 'hand')
    if (state.movements) bot.pvp.movements = state.movements
    say(`Defending myself from ${target.name} with ${weapon.name}.`)
    await bot.pvp.attack(target)

    const fightDeadline = Date.now() + Number(config.combat.maxFightSeconds || 18) * 1000
    while (Date.now() < fightDeadline) {
      if (state.stopRequested || state.homeRequested) break
      if (!bot.entities[target.id] || target.isValid === false || !bot.pvp.target) break
      if (typeof bot.health === 'number' && bot.health <= Number(config.combat.retreatHealth || 8)) {
        await bot.pvp.stop()
        state.running = false
        say(`Retreating: health fell to ${bot.health}/20 during combat. Heal before mining again.`)
        await goHome()
        return true
      }
      if (target.position && target.position.distanceTo(bot.entity.position) > Number(config.combat.detectRadius || 9) + 5) break
      await sleep(250)
    }

    await bot.pvp.stop()
    const targetStillPresent = Boolean(bot.entities[target.id]) && target.isValid !== false
    if (!targetStillPresent) {
      state.mobsDefeated++
      say(`${target.name} defeated. Continuing mining.`)
    } else if (state.stopRequested || state.homeRequested) {
      say('Combat stopped because a stop/return command was requested.')
    } else {
      say(`${target.name} moved away or the fight timed out. I stopped chasing to avoid getting lost; continuing cautiously.`)
    }
    return true
  } catch (error) {
    try { await bot.pvp.stop() } catch {}
    console.warn('[COMBAT]', error.stack || error.message)
    say(`Combat could not be completed: ${error.message}. Mining will pause.`)
    state.running = false
    return true
  } finally {
    state.combatBusy = false
  }
}

function isChestBlock (block) {
  return block && (block.name === 'chest' || block.name === 'trapped_chest')
}

async function setStorageChest () {
  if (state.busy) {
    say('Stop mining first with !stop, then move me next to the chest and use !setchest.')
    return
  }
  const chestIds = ['chest', 'trapped_chest']
    .map(name => bot.registry.blocksByName[name]?.id)
    .filter(id => Number.isInteger(id))
  const positions = bot.findBlocks({ matching: chestIds, maxDistance: 6, count: 20 })
  const block = positions.map(position => bot.blockAt(position)).find(isChestBlock)
  if (!isChestBlock(block)) {
    say('I cannot find a chest within 6 blocks. Move me next to the chest and use !setchest again.')
    return
  }
  const p = block.position.floored()
  state.chestPosition = { x: p.x, y: p.y, z: p.z }
  config.storage.chestPosition = state.chestPosition
  saveConfig()
  say(`Storage chest saved at ${p.x}, ${p.y}, ${p.z}. I will deposit diamonds there automatically.`)
}

async function depositDiamonds (automatic = false) {
  const amount = countDiamonds()
  if (amount <= 0) {
    if (!automatic) say('I have no diamonds to deposit.')
    return 0
  }
  if (!state.chestPosition) {
    say('No storage chest is configured. Look at a chest and use !setchest first.')
    return 0
  }

  const returnPosition = bot.entity.position.floored()
  const chestPos = state.chestPosition
  let container = null
  let deposited = 0

  try {
    let chestBlock = bot.blockAt(chestPos)
    if (!isChestBlock(chestBlock)) {
      await bot.pathfinder.goto(new goals.GoalNear(chestPos.x, chestPos.y, chestPos.z, 2))
      chestBlock = bot.blockAt(chestPos)
    }
    if (!isChestBlock(chestBlock)) {
      throw new Error('The saved chest is not loaded or is no longer a chest. Re-aim at the correct chest and use !setchest.')
    }

    const distance = bot.entity.position.distanceTo(chestBlock.position)
    if (distance > 4.5) {
      await bot.pathfinder.goto(new goals.GoalNear(chestPos.x, chestPos.y, chestPos.z, 2))
    }

    chestBlock = bot.blockAt(chestPos)
    if (!isChestBlock(chestBlock)) throw new Error('Could not locate the saved chest after pathfinding.')

    container = await bot.openContainer(chestBlock)
    // Re-check inventory on each pass because a successful deposit updates slot contents.
    while (true) {
      const stack = bot.inventory.items().find(item => item.name === 'diamond')
      if (!stack) break
      const stackCount = stack.count
      await container.deposit(stack.type, stack.metadata ?? null, stackCount)
      deposited += stackCount
    }
    container.close()
    container = null
    say(`Deposited ${deposited} diamond(s) into the saved chest. ${countDiamonds()} remain in my inventory.`)
  } catch (error) {
    say(`Could not deposit diamonds: ${error.message}`)
  } finally {
    if (container) {
      try { container.close() } catch {}
    }
    if (config.storage.returnAfterDeposit && state.spawned && bot.entity) {
      const now = bot.entity.position
      const distance = now.distanceTo(returnPosition)
      if (distance > 3) {
        try {
          await bot.pathfinder.goto(new goals.GoalNear(returnPosition.x, returnPosition.y, returnPosition.z, 2))
        } catch (error) {
          say(`Diamonds were handled, but I could not return to the previous position: ${error.message}`)
        }
      }
    }
  }
  return deposited
}

async function maybeAutoDepositDiamonds (force = false) {
  if (!config.storage.autoDepositDiamonds || !state.chestPosition || countDiamonds() <= 0) return false
  const threshold = Math.max(1, Number(config.storage.depositAtCount || 16))
  const inventoryNearlyFull = countOccupiedInventorySlots() >= maxSlots - 1
  if (!force && countDiamonds() < threshold && !inventoryNearlyFull) return false
  await depositDiamonds(true)
  return true
}

async function pickupNearbyItems () {
  if (state.busy) {
    say('I am already busy. Use !stop before asking me to pick up items.')
    return
  }
  const drops = Object.values(bot.entities).filter(entity => {
    return entity && entity.name === 'item' && entity.isValid &&
      entity.position && entity.position.distanceTo(bot.entity.position) <= 8
  })
  if (!drops.length) {
    say('I cannot see any dropped items within 8 blocks. Drop the pickaxe, sword/axe and food near me, then retry !pickup.')
    return
  }
  state.busy = true
  try {
    await bot.collectBlock.collect(drops)
    say(`Picked up nearby items. Iron-tier pickaxe ready: ${hasSafePickaxe() ? 'yes' : 'no'}; melee weapon ready: ${bestMeleeWeapon() ? 'yes' : 'no'}.`)
  } catch (error) {
    say(`Could not pick up all nearby items: ${error.message}`)
  } finally {
    state.busy = false
  }
}

async function mineNearestDiamond () {
  const block = findNearestSafeDiamond()
  if (!block) return false

  const key = posKey(block.position)
  console.log(`[SCAN] Diamond ore detected at ${key}`)
  try {
    const bestTool = bot.pathfinder.bestHarvestTool(block)
    if (!bestTool || !['iron_pickaxe', 'diamond_pickaxe', 'netherite_pickaxe'].includes(bestTool.name)) {
      say('I found diamond ore, but no iron-tier-or-better pickaxe can harvest it.')
      state.running = false
      return true
    }
    await equipBestToolFor(block)
    await bot.collectBlock.collect(block, { ignoreNoPath: false })
    state.minedOres++
    state.failedTargets = 0
    say(`Collected an ore block. Diamonds in inventory: ${countDiamonds()}.`)
    return true
  } catch (error) {
    if (state.combatRequested) {
      console.log(`[COMBAT] Mining action interrupted for nearby hostile: ${error.message}`)
      return true
    }
    state.blacklist.set(key, Date.now() + 90_000)
    state.failedTargets++
    console.warn(`[MINING] Could not collect ${key}: ${error.message}`)
    if (state.failedTargets >= maxFailedTargets) {
      state.running = false
      say('Too many unreachable ore targets. Stopping to avoid getting stuck.')
    }
    return true
  }
}

function getBlockAtOrStop (position, label) {
  const block = bot.blockAt(position)
  if (!block) throw new Error(`${label} is not loaded; refusing to dig blindly.`)
  return block
}

async function digIfNeeded (block) {
  if (blockIsAir(block)) return
  if (!block.diggable || !bot.canDigBlock(block)) throw new Error(`Cannot safely dig ${block.name}.`)
  if (isHazardous(block) || nearbyLiquidOrHazard(block)) throw new Error(`A liquid or hazard is beside ${block.name}; refusing to dig it.`)
  if (isGravityBlock(block)) throw new Error(`Found falling block ${block.name}; refusing to dig beneath it.`)
  await equipBestToolFor(block)
  await bot.dig(block)
}

async function tunnelOneStep () {
  const current = bot.entity.position.floored()
  const feetY = current.y
  if (Math.abs(feetY - miningY) > 1) {
    state.running = false
    say(`I am at Y=${feetY}; the configured branch-mining level is Y=${miningY}. Move me to the correct level and use !mine again.`)
    return false
  }

  const nextFeetPosition = current.offset(direction.x, 0, direction.z)
  const nx = nextFeetPosition.x
  const nz = nextFeetPosition.z
  const frontFeet = getBlockAtOrStop(nextFeetPosition, 'Tunnel foot block')
  const frontHead = getBlockAtOrStop(nextFeetPosition.offset(0, 1, 0), 'Tunnel head block')
  const frontFloor = getBlockAtOrStop(nextFeetPosition.offset(0, -1, 0), 'Tunnel floor')

  if (blockIsAir(frontFloor) || isHazardous(frontFloor)) throw new Error('The next tunnel floor is missing or unsafe. Stopping instead of risking a fall.')
  if (isHazardous(frontFeet) || isHazardous(frontHead)) throw new Error('Water/lava is directly ahead. Stopping the tunnel.')
  const ceiling = getBlockAtOrStop(nextFeetPosition.offset(0, 2, 0), 'Tunnel ceiling')
  if (isGravityBlock(ceiling) || isGravityBlock(frontHead)) throw new Error('Falling blocks detected above the tunnel. Stopping for safety.')

  await digIfNeeded(frontHead)
  await digIfNeeded(frontFeet)
  await bot.pathfinder.goto(new goals.GoalBlock(nx, feetY, nz))
  state.tunnelSteps++
  if (state.tunnelSteps % 10 === 0) say(`Tunnel progress: ${state.tunnelSteps}/${maxTunnelSteps} blocks. Diamonds: ${countDiamonds()}.`)
  return true
}

async function goHome () {
  if (!state.homePosition || !bot.entity) {
    say('I do not have a saved home position yet.')
    return
  }
  try {
    say('Returning to the saved starting position...')
    await bot.pathfinder.goto(new goals.GoalNear(
      state.homePosition.x,
      state.homePosition.y,
      state.homePosition.z,
      2
    ))
    say('I reached the saved starting area.')
  } catch (error) {
    say(`Could not reach the saved position: ${error.message}`)
  }
}

async function miningLoop () {
  if (state.busy) return
  state.busy = true
  state.stopRequested = false
  state.homeRequested = false
  state.combatRequested = false
  state.tunnelSteps = 0
  state.failedTargets = 0
  state.homePosition = bot.entity.position.floored()

  try {
    await eatFoodIfNeeded().catch(error => console.warn('[FOOD]', error.message))
    const reason = safetyStopReason()
    if (reason) {
      say(reason)
      return
    }

    state.running = true
    say(`Mining started. Scanning loaded blocks within ${scanRadius} blocks, then branch-mining toward ${config.mining.tunnelDirection} at Y=${miningY}.`)

    while (state.running && !state.stopRequested && !state.homeRequested) {
      if (state.combatRequested) {
        await fightNearbyHostile()
        if (!state.running || state.stopRequested || state.homeRequested) break
      }

      await eatFoodIfNeeded().catch(error => console.warn('[FOOD]', error.message))
      await maybeAutoDepositDiamonds(false).catch(error => say(`Automatic chest deposit failed: ${error.message}`))
      if (state.combatRequested) {
        await fightNearbyHostile()
        if (!state.running || state.stopRequested || state.homeRequested) break
        continue
      }
      const stopReason = safetyStopReason()
      if (stopReason) {
        say(stopReason)
        state.running = false
        break
      }

      const foundOre = await mineNearestDiamond()
      if (state.combatRequested) {
        await fightNearbyHostile()
        if (!state.running || state.stopRequested || state.homeRequested) break
        continue
      }
      if (state.stopRequested || state.homeRequested || !state.running) break
      if (foundOre) {
        await sleep(350)
        continue
      }

      if (state.tunnelSteps >= maxTunnelSteps) {
        say(`Reached the configured tunnel limit of ${maxTunnelSteps} blocks. Stopping.`)
        state.running = false
        break
      }

      try {
        await tunnelOneStep()
      } catch (error) {
        if (state.combatRequested) {
          console.log(`[COMBAT] Tunnel action interrupted for nearby hostile: ${error.message}`)
        } else {
          state.running = false
          say(`Safety stop: ${error.message}`)
        }
      }
      if (state.combatRequested && state.running) {
        await fightNearbyHostile()
        if (!state.running) break
      }
      await sleep(150)
    }
  } finally {
    state.running = false
    try {
      // Store any remaining diamonds when a mining session ends, then return home if requested.
      if (config.storage.autoDepositDiamonds && state.chestPosition && countDiamonds() > 0) {
        await maybeAutoDepositDiamonds(true)
      }

      if (state.homeRequested) {
        state.homeRequested = false
        await goHome()
      } else if (state.stopRequested) {
        say('Mining stopped.')
      }
    } finally {
      state.busy = false
    }
  }
}

async function goToOwner () {
  const player = bot.players[config.owner]?.entity
  if (!player) {
    say(`I cannot see ${config.owner}. Make sure they are online and nearby.`)
    return
  }
  const p = player.position.floored()
  state.homePosition = { x: p.x, y: p.y, z: p.z }
  try {
    say(`Moving toward ${config.owner}...`)
    await bot.pathfinder.goto(new goals.GoalNear(p.x, p.y, p.z, 2))
    say('I reached your location. Place me safely at the mining level, then use !mine.')
  } catch (error) {
    say(`Could not reach you: ${error.message}`)
  }
}

async function handleCommand (username, message) {
  if (username !== config.owner) return
  const command = message.trim().toLowerCase()
  if (!command.startsWith('!')) return

  if (command === '!help') {
    say('Commands: !pickup, !setchest, !chest, !deposit, !mine, !stop, !home, !come, !status, !help')
  } else if (command === '!pickup') {
    await pickupNearbyItems()
  } else if (command === '!setchest') {
    await setStorageChest()
  } else if (command === '!chest') {
    if (state.chestPosition) {
      const p = state.chestPosition
      say(`Saved diamond chest: ${p.x}, ${p.y}, ${p.z}. Auto-deposit: ${config.storage.autoDepositDiamonds ? 'on' : 'off'}.`)
    } else {
      say('No chest saved. Look directly at a chest and use !setchest.')
    }
  } else if (command === '!deposit') {
    if (state.busy) return say('I am busy. Use !stop first, then use !deposit.')
    state.busy = true
    try { await depositDiamonds(false) } finally { state.busy = false }
  } else if (command === '!mine') {
    if (state.busy) return say('I am already working. Use !stop to stop after my current action.')
    void miningLoop()
  } else if (command === '!stop') {
    state.stopRequested = true
    state.running = false
    state.combatRequested = false
    try { bot.pvp.stop() } catch {}
    if (state.busy && bot.collectBlock) {
      void bot.collectBlock.cancelTask().catch(error => console.warn('[STOP]', error.message))
    }
    say('Stop requested. I will finish/cancel the current action, store diamonds if configured, then stop.')
  } else if (command === '!home') {
    state.stopRequested = true
    state.running = false
    state.homeRequested = true
    state.combatRequested = false
    try { bot.pvp.stop() } catch {}
    if (state.busy && bot.collectBlock) {
      void bot.collectBlock.cancelTask().catch(error => console.warn('[HOME]', error.message))
    }
    if (!state.busy) {
      state.homeRequested = false
      await goHome()
    } else {
      say('Stop-and-return requested. I will store diamonds if configured, then return.')
    }
  } else if (command === '!come') {
    if (state.busy) return say('Stop mining first with !stop, then use !come.')
    await goToOwner()
  } else if (command === '!status') {
    say(`Status: ${state.running ? 'mining' : 'idle'} | health ${bot.health}/20 | food ${bot.food}/20 | diamonds ${countDiamonds()} | saved chest ${state.chestPosition ? 'yes' : 'no'} | mobs defeated ${state.mobsDefeated} | tunnel ${state.tunnelSteps}/${maxTunnelSteps} | ores collected ${state.minedOres}.`)
  } else {
    say('Unknown command. Use !help.')
  }
}

bot.once('spawn', async () => {
  state.spawned = true
  state.homePosition = bot.entity.position.floored()

  const movements = new Movements(bot)
  movements.canDig = true
  movements.allowParkour = false
  movements.allow1by1towers = false
  movements.maxDropDown = 1
  movements.dontCreateFlow = true

  const lavaId = bot.registry.blocksByName.lava?.id
  const waterId = bot.registry.blocksByName.water?.id
  if (Number.isInteger(lavaId)) movements.blocksToAvoid.add(lavaId)
  if (Number.isInteger(waterId)) movements.blocksToAvoid.add(waterId)

  state.movements = movements
  bot.pathfinder.setMovements(movements)
  bot.collectBlock.movements = null
  bot.pvp.movements = movements

  if (config.combat.enabled) {
    const intervalMs = 750
    state.hostileScanTimer = setInterval(requestCombatInterrupt, intervalMs)
  }

  say(`Connected to ${config.server.host}:${port} as ${bot.username}.`)
  say('I am idle and waiting for your command. Use !help in chat.')
  say(`Server protocol detected: ${bot.version}.`)
  if (!hasSafePickaxe()) say('Warning: bring an iron, diamond, or netherite pickaxe before using !mine.')
  if (!bestMeleeWeapon()) say('Warning: bring a sword or axe so I can defend myself from nearby hostile mobs.')
  if (!state.chestPosition) say('No storage chest saved yet. Aim at a chest and use !setchest to enable diamond deposits.')
})

bot.on('chat', (username, message) => {
  void handleCommand(username, message).catch(error => {
    console.error(`[COMMAND] ${error.stack || error.message}`)
    say(`Command failed: ${error.message}`)
  })
})

bot.on('kicked', reason => console.error('[KICKED]', reason))
bot.on('error', error => console.error('[ERROR]', error.stack || error.message))
bot.on('end', () => {
  state.spawned = false
  state.running = false
  if (state.hostileScanTimer) clearInterval(state.hostileScanTimer)
  try { bot.pvp.stop() } catch {}
  console.log('[BOT] Disconnected. No automatic reconnect will be attempted.')
})

process.on('SIGINT', () => {
  console.log('\nStopping bot...')
  if (state.hostileScanTimer) clearInterval(state.hostileScanTimer)
  try { bot.pvp.stop() } catch {}
  try { bot.quit('Bot stopped locally.') } catch {}
  setTimeout(() => process.exit(0), 750).unref()
})
