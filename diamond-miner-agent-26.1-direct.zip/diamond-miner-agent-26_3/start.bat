@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed or is not on PATH.
  echo Install Node.js 20 or later from https://nodejs.org/ and reopen this window.
  pause
  exit /b 1
)
if not exist config.json (
  copy config.example.json config.json >nul
  echo Created config.json from the example.
  echo The Aternos host and port are prefilled. Add your bot account and owner username, then run start.bat again.
  pause
  exit /b 0
)
if not exist node_modules\mineflayer\package.json (
  echo Installing dependencies...
  call npm install
  if errorlevel 1 (
    echo Dependency installation failed.
    pause
    exit /b 1
  )
)
if not exist node_modules\mineflayer-pvp\package.json (
  echo Installing/updating the combat dependency...
  call npm install
  if errorlevel 1 (
    echo Dependency installation failed.
    pause
    exit /b 1
  )
)
call npm start
pause
